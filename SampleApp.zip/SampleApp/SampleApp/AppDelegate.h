//
//  AppDelegate.h
//  SampleApp
//
//  Created by apple on 2023/5/6.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

